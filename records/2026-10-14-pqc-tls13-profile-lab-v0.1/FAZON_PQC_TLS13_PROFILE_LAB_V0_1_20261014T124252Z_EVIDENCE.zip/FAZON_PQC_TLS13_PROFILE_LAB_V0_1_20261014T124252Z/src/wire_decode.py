#!/usr/bin/env python3
"""Offline bounded TLS record/ClientHello/ServerHello decoder.
No TLS decryption. Does not infer application success from encrypted records.
Only the handshake structures needed by the declared three-case experiment.
"""
from __future__ import annotations
import argparse,json
from pathlib import Path
GROUPS={24:'secp384r1',4589:'SecP384r1MLKEM1024'}
HRR=bytes.fromhex('CF21AD74E59A6111BE1D8C021E65B891C2A211167ABB8C5E079E09E2C8A8339C')
class ParseError(ValueError):pass
class R:
    def __init__(self,b):self.b=b;self.i=0
    def take(self,n):
        if n<0 or self.i+n>len(self.b):raise ParseError('truncated field')
        v=self.b[self.i:self.i+n];self.i+=n;return v
    def u8(self):return int.from_bytes(self.take(1),'big')
    def u16(self):return int.from_bytes(self.take(2),'big')
    def vec8(self):return self.take(self.u8())
    def vec16(self):return self.take(self.u16())
    def end(self):
        if self.i!=len(self.b):raise ParseError('unconsumed bytes')
def extensions(b):
    r=R(b);ext={}
    while r.i<len(b):
        t=r.u16();v=r.vec16()
        if t in ext:raise ParseError('duplicate extension')
        ext[t]=v
    return ext

def client_hello(b):
    r=R(b);legacy=r.u16();r.take(32);r.vec8();r.vec16();r.vec8();ext=extensions(r.vec16());r.end()
    groups=[];shares=[];versions=[]
    if 10 in ext:
        rr=R(ext[10]);gg=R(rr.vec16());rr.end()
        while gg.i<len(gg.b):groups.append(gg.u16())
    if 51 in ext:
        rr=R(ext[51]);ss=R(rr.vec16());rr.end()
        while ss.i<len(ss.b):
            g=ss.u16();v=ss.vec16();shares.append({'group_id':g,'group_name':GROUPS.get(g,'UNMAPPED'),'key_exchange_bytes':len(v)})
    if 43 in ext:
        rr=R(ext[43]);vv=R(rr.vec8());rr.end()
        while vv.i<len(vv.b):versions.append(vv.u16())
    return {'kind':'ClientHello','legacy_version':legacy,'offered_group_ids':groups,'offered_groups':[GROUPS.get(x,'UNMAPPED') for x in groups],'key_shares':shares,'offered_versions':versions,'early_data_extension':42 in ext,'pre_shared_key_extension':41 in ext}

def server_hello(b):
    r=R(b);legacy=r.u16();rand=r.take(32);r.vec8();cipher=r.u16();r.u8();ext=extensions(r.vec16());r.end();hrr=rand==HRR
    g=None;length=None
    if 51 in ext:
        rr=R(ext[51]);g=rr.u16()
        if not hrr:length=len(rr.vec16())
        rr.end()
    version=int.from_bytes(ext[43],'big') if 43 in ext else legacy
    return {'kind':'HelloRetryRequest' if hrr else 'ServerHello','selected_version':version,'cipher_suite_id':cipher,'selected_group_id':g,'selected_group':GROUPS.get(g,'UNMAPPED'),'key_exchange_bytes':length,'pre_shared_key_selected':41 in ext}

def decode(data):
    r=R(data);records=[];handshakes=[];alerts=[];pending=b''
    while r.i<len(data):
        offset=r.i;t=r.u8();version=r.u16();body=r.take(r.u16())
        records.append({'offset':offset,'content_type':t,'legacy_record_version':version,'length':len(body)})
        if t==22:
            pending+=body
            while len(pending)>=4:
                typ=pending[0];n=int.from_bytes(pending[1:4],'big')
                if len(pending)<4+n:break
                b=pending[4:4+n];pending=pending[4+n:]
                if typ==1:handshakes.append(client_hello(b))
                elif typ==2:handshakes.append(server_hello(b))
                else:handshakes.append({'kind':'OtherPlaintextHandshake','type':typ,'length':n})
        elif t==21:
            if len(body)%2:raise ParseError('malformed alert')
            for i in range(0,len(body),2):alerts.append({'level':body[i],'description':body[i+1]})
    if pending:raise ParseError('incomplete plaintext handshake')
    return {'byte_count':len(data),'records':records,'handshakes':handshakes,'plaintext_alerts':alerts,'complete_record_parse':True,'decryption_performed':False}

def selftest():
    # Grammar checks only; not extra live TLS sessions.
    passed=[]
    try:decode(b'\x16\x03');raise AssertionError('truncation accepted')
    except ParseError:passed.append('truncated_record_rejected')
    def v16(x):return len(x).to_bytes(2,'big')+x
    def ext(t,x):return t.to_bytes(2,'big')+v16(x)
    for gid in (4589,24):
        ex=ext(43,b'\x03\x04')+ext(51,gid.to_bytes(2,'big')+v16(b'\x01'))
        sh=b'\x03\x03'+bytes(32)+b'\x00\x13\x02\x00'+v16(ex)
        hs=b'\x02'+len(sh).to_bytes(3,'big')+sh
        rec=b'\x16\x03\x03'+v16(hs)
        d=decode(rec);assert d['handshakes'][0]['selected_group_id']==gid
        passed.append('synthetic_group_'+str(gid))
        parts=hs[:7],hs[7:]
        d=decode(b''.join(b'\x16\x03\x03'+v16(q) for q in parts));assert len(d['handshakes'])==1
        passed.append('fragmented_handshake_'+str(gid))
    d=decode(b'\x15\x03\x03\x00\x02\x02\x28');assert d['plaintext_alerts']==[{'level':2,'description':40}]
    passed.append('fatal_handshake_failure_decoded')
    try:extensions(b'\x00\x2b\x00\x02\x03\x04'*2);raise AssertionError('duplicate accepted')
    except ParseError:passed.append('duplicate_extension_rejected')
    return {'scope':'OFFLINE_PARSER_SELFTEST_NOT_TLS_INTEROPERABILITY','passed':passed,'count':len(passed)}
if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('stream',type=Path,nargs='?');p.add_argument('--selftest',action='store_true');a=p.parse_args()
    print(json.dumps(selftest() if a.selftest else decode(a.stream.read_bytes()),indent=2))
