#!/usr/bin/env python3
"""Single-session loopback TCP recorder. No TLS termination or byte modification.
Captures reassembled TCP stream bytes, not IP packets / PCAP.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, selectors, socket, time
from pathlib import Path

def utc(): return dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z')
def main():
    p=argparse.ArgumentParser()
    p.add_argument('--target-port',type=int,required=True)
    p.add_argument('--out',type=Path,required=True)
    args=p.parse_args(); out=args.out; out.mkdir(parents=True,exist_ok=True)
    ev=open(out/'relay_events.jsonl','x',encoding='utf-8')
    seq=0
    def log(kind,**kw):
        nonlocal seq
        seq+=1
        rec={'sequence':seq,'observed_at_utc':utc(),'monotonic_ns':time.monotonic_ns(),'event':kind,**kw}
        ev.write(json.dumps(rec,sort_keys=True)+'\n');ev.flush()
    listener=socket.socket(socket.AF_INET,socket.SOCK_STREAM)
    listener.bind(('127.0.0.1',0)); listener.listen(1); listener.settimeout(20)
    port=listener.getsockname()[1]
    (out/'relay_ready.json').write_text(json.dumps({'host':'127.0.0.1','port':port,'target_host':'127.0.0.1','target_port':args.target_port,'created_at_utc':utc()},indent=2)+'\n')
    streams={}; reads={}; totals={'client_to_server':0,'server_to_client':0}; errors=[]
    c=s=None; sel=selectors.DefaultSelector()
    try:
        c,addr=listener.accept();listener.close()
        log('client_accepted',peer_host=addr[0],peer_port=addr[1])
        s=socket.create_connection(('127.0.0.1',args.target_port),timeout=10)
        for sock in (c,s): sock.settimeout(5)
        for src,dst,label in [(c,s,'client_to_server'),(s,c,'server_to_client')]:
            streams[label]=open(out/(label+'.bin'),'xb')
            sel.register(src,selectors.EVENT_READ,(dst,label))
        deadline=time.monotonic()+20
        while sel.get_map():
            if time.monotonic()>deadline: raise TimeoutError('RELAY_SESSION_DEADLINE')
            for key,_ in sel.select(.1):
                dst,label=key.data
                data=key.fileobj.recv(65536)
                if not data:
                    log('eof',direction=label)
                    sel.unregister(key.fileobj)
                    try: dst.shutdown(socket.SHUT_WR)
                    except OSError: pass
                    continue
                offset=totals[label]; streams[label].write(data);streams[label].flush();totals[label]+=len(data)
                log('bytes_observed',direction=label,offset=offset,length=len(data),sha256=hashlib.sha256(data).hexdigest())
                dst.sendall(data)
                log('bytes_forwarded',direction=label,offset=offset,length=len(data))
        log('session_complete',**totals)
    except Exception as ex:
        errors.append(type(ex).__name__+': '+str(ex)); log('relay_error',error=errors[-1])
    finally:
        for f in streams.values(): f.close()
        for sock in (listener,c,s):
            if sock:
                try:sock.close()
                except OSError:pass
        sel.close();ev.close()
        summary={'completed':not errors,'errors':errors,'total_bytes':totals,'connections_accepted':1 if c else 0,'capture_type':'TCP_STREAM_NOT_PCAP','tls_terminated_by_relay':False,'byte_mutation_by_relay':False}
        (out/'relay_result.json').write_text(json.dumps(summary,indent=2)+'\n')
    return 0 if not errors else 2
if __name__=='__main__': raise SystemExit(main())
