# Changelog — FAZON-REC-2026-01-27-GOLDENPATH-MAP-v1

## v1
- Initial canonical mapping of FAZON to Golden Path layers.
