# TR-FS Public Verification
Record ID: FAZON-REC-2026-01-27-GOLDENPATH-MAP-v1

This file lists artifact hashes for public verification.
No internal URLs or infrastructure details are included.

## Artifacts (SHA-256)
- evidence-pack.pdf: 5a5ad99122d96636df2d89ad75eb38fa658717a61b5608e4fe6e9fa9ff3b6387
- definitions.md: e66518a098d51ab95b5bd036313cf987ba81cbfbb114ed07b0ebd6c4207cda69
- claims.md: 54c26617fa1a7115702eeb173fead272faea9b903c04c3b6af25c547f64f87f9
- changelog.md: 32aaae7da637ec24cb14f2e05119ed5a025533cd51b4d6f491688e2221da4ad6
- README.md: d888385866632b0b11b2cbf577d30403b6195adc166b0529b0df33fad58a7a1e
