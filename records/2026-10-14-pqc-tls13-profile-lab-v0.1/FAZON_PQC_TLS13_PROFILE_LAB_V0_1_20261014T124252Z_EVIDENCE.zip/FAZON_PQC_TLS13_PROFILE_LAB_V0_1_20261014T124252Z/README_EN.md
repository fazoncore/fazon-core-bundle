# FAZON — Bounded TLS 1.3 Profile Check, v0.1

**LABORATORY EVIDENCE CANDIDATE — NOT YET PUBLISHED OR RELEASE-VERIFIED**

## Result

Three real, fresh TLS 1.3 connection attempts were executed on loopback using OpenSSL 3.5.5.
The declared acceptance matrix passed 3/3. This is one observation per case, not a reliability estimate.

| Case | Observed group | Session established | Server application bytes | Lab-profile classification | Test |
|---|---|---:|---:|---|---|
| C1_APPROVED_HYBRID | SecP384r1MLKEM1024 | True | 42 | WITHIN_DECLARED_PROFILE | PASS |
| C2_NO_COMMON_APPROVED_GROUP | None; fatal alert 40 | False | 0 | NO_SESSION_ESTABLISHED | PASS |
| C3_INJECTED_CLASSICAL_FALLBACK | secp384r1 | True | 54 | OUTSIDE_DECLARED_PROFILE | PASS |

Case 3 passing means the deliberately incorrect profile was **detected**. The session itself was outside the baseline and the test data reached the server. No pre-action FAZON gate blocked that case.

Observation window: 2026-10-14T12:42:53.829311Z to 2026-10-14T12:42:55.504495Z.
The local protocol and source-hash freeze predates the first connection; it is not an externally timestamped preregistration.

## What was tested

`protocol.json` fixes only group 4589 (`SecP384r1MLKEM1024`) as permitted by this **laboratory** baseline. Both success cases use `TLS_AES_256_GCM_SHA384`, demonstrating that the cipher-suite label alone does not identify the key-exchange group.

1. Hybrid-only client and server: the captured ServerHello selected group 4589; the server received the exact 42-byte marker and the client received a reply.
2. Hybrid-only client, classical-only server: no final ServerHello; the recorded fatal handshake_failure alert was 40; the client exited 1; the server produced zero application bytes. The server process itself exited 0 after its configured one-connection limit. A process exit code alone would misclassify this case.
3. Client list deliberately widened to include `secp384r1`, classical-only server: a HelloRetryRequest asked for group 24, followed by a final ServerHello selecting group 24; the server received the exact 54-byte marker. The offline rule marked it outside the original baseline. This is intentional configuration drift, NOT a hostile network downgrade, NOT an OpenSSL vulnerability and NOT proof of runtime exception authorization.

## Observation chain

Client and server were separate OpenSSL processes. A separate single-session loopback TCP relay recorded both byte streams without TLS termination. The disclosed decoder reads supported_groups and key_share, distinguishes HRR from a final ServerHello, and does not decrypt application records. Receiver stdout is the application's plaintext observation. The acknowledgement was supplied through server stdin only after its stdout contained the marker; it is corroboration, not an independent organizational attestation.

The recorder is a separate observation path under the same local control, not an independent laboratory. Raw streams are TCP-stream captures, not PCAP. Network packet timings, retransmission details, and all possible alternate routes are not covered.

The exact raw commands, exit codes, stream bytes, recorder segment digests, OpenSSL traces, marker bytes and derived classifications are supplied in `raw/`.

## Verification performed

- 44 case-level assertions in the executing harness (14 + 16 + 14), all satisfied.
- 7 offline parser checks, all satisfied; these are not additional live TLS sessions.
- 65/65 separate offline rechecks, all satisfied. The offline checker reuses the disclosed bounded parser and is not independent validation.
- Byte-preserving packaging and SHA-256 manifest checks are recorded separately.

## Controls and exclusions

TLS 1.3 only; no PSK resumption, no 0-RTT, no reconnect retries, no external endpoints. Three logical TLS attempts used six loopback TCP legs due to the recording relay. The third attempt contains HRR, not a second TCP connection. Server tickets and cache were disabled. ClientHello carried no pre_shared_key or early_data extension. OpenSSL state text can still say `TLSv1.3 early data`; that state label is not evidence of 0-RTT application data.

A fresh, self-signed ECDSA P-384 certificate was explicitly trusted and hostname-verified by the client. Authentication is **classical**, not post-quantum. No mutual client-certificate authentication was tested. Hybrid exchange success does not establish all-PQ authentication, CNSA compliance, FIPS validation or resistance to cryptanalysis.

The temporary server private key was stored outside the evidence tree and its temporary file was removed after all processes exited. No TLS key log, private key, production credentials, user data, private manuscript or private correspondence is included. File deletion is not a claim of forensic secure erasure.

## Reproduce / review

Offline (no sockets, no installation):

```sh
python3 src/offline_review.py .
```

A separately authorized live reproduction on Linux with compatible OpenSSL 3.5.x:

```sh
python3 src/run_lab.py --out /absolute/path/to/a/new-empty-run-directory
```

The script refuses an existing output directory. It creates fresh synthetic keys, so raw transcript bytes and certificate hashes will differ. Semantic outcomes, not bit-for-bit live reproduction, are the target. It inspects `/proc/net/tcp` for readiness and does not open extra test connections. No package installation or dependency downloads occur.

## Claim ceiling

This record supports the three observed cases only. It does not demonstrate a deployed FAZON authorization service, no-bypass enforcement, certificate revocation handling, dynamic mandates, session reuse behavior, client diversity, production interoperability, performance, formal verification, independent certification or compliance with a complete procurement regime.

A baseline check after a session **detects** an out-of-profile session; it does not retroactively prevent or authorize it. OpenSSL enforced the group list it was actually given. The experiment does not implement organizational approval or a protected configuration writer.

## Publication state

GitHub write: false. Public reply: false. Owner acceptance of this exact package: pending.
Repository release-policy verification, Sigstore bundle and Rekor binding: not performed in this local lab. SHA-256/CRC are not replacements for those requirements. Source pointers are in `SOURCE_REFERENCES.json`.
