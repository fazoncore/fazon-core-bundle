#!/usr/bin/env python3
"""Read-only offline recheck; never opens sockets or runs OpenSSL.
Reuses the disclosed bounded wire parser; not an independent laboratory review.
Does not trust the test harness's PASS label as evidence.
"""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,re
from pathlib import Path
from wire_decode import decode

def sha(b):return hashlib.sha256(b).hexdigest()
def main():
    ap=argparse.ArgumentParser();ap.add_argument('root',type=Path);args=ap.parse_args();r=args.root.resolve()
    policy=json.loads((r/'protocol.json').read_text());freeze=json.loads((r/'PRE_RUN_FREEZE.json').read_text())
    checks=[]
    def check(name,value,detail=''):
        checks.append({'id':name,'passed':bool(value),'detail':detail})
    check('protocol_unchanged',sha((r/'protocol.json').read_bytes())==freeze['protocol_sha256'])
    for name,h in freeze['source_sha256'].items():check('frozen_source_'+name,sha((r/'src'/name).read_bytes())==h)
    rows=[]
    for case in policy['cases']:
        cid=case['id'];d=r/'raw'/cid
        decoded={};events=[json.loads(s) for s in (d/'wire'/'relay_events.jsonl').read_text().splitlines()]
        for label in ('client_to_server','server_to_client'):
            b=(d/'wire'/(label+'.bin')).read_bytes();decoded[label]=decode(b)
            observed=[x for x in events if x['event']=='bytes_observed' and x['direction']==label]
            forwarded=[x for x in events if x['event']=='bytes_forwarded' and x['direction']==label]
            ofs=0;ok=True
            for x in observed:
                segment=b[x['offset']:x['offset']+x['length']]
                ok=ok and x['offset']==ofs and len(segment)==x['length'] and sha(segment)==x['sha256'];ofs+=x['length']
            check(cid+'_'+label+'_capture_chain',ok and ofs==len(b))
            check(cid+'_'+label+'_forwarding_accounted',[(x['offset'],x['length']) for x in observed]==[(x['offset'],x['length']) for x in forwarded])
            check(cid+'_'+label+'_eof',sum(x['event']=='eof' and x.get('direction')==label for x in events)==1)
        check(cid+'_single_connection',sum(x['event']=='client_accepted' for x in events)==1)
        check(cid+'_capture_complete',sum(x['event']=='session_complete' for x in events)==1 and not any(x['event']=='relay_error' for x in events))
        sh=[x for x in decoded['server_to_client']['handshakes'] if x['kind']=='ServerHello']
        ch=[x for x in decoded['client_to_server']['handshakes'] if x['kind']=='ClientHello']
        group=sh[-1]['selected_group_id'] if sh else None
        hrr=sum(x['kind']=='HelloRetryRequest' for x in decoded['server_to_client']['handshakes'])
        c_log=(d/'client.stderr.txt').read_text();s_log=(d/'server.stderr.txt').read_text()
        cout=(d/'client.stdout.txt').read_bytes();sout=(d/'server.stdout.txt').read_bytes();marker=(d/'client_input.bin').read_bytes();ack=(d/'expected_ack.bin').read_bytes()
        cp=json.loads((d/'client.process.json').read_text());sp=json.loads((d/'server.process.json').read_text());rp=json.loads((d/'relay.process.json').read_text())
        established='CONNECTION ESTABLISHED' in c_log
        check(cid+'_exact_offered_groups',all(x['offered_group_ids']==([4589,24] if cid.startswith('C3') else [4589]) for x in ch) and len(ch)>=1)
        check(cid+'_no_PSK_no_early_data',bool(ch) and all(not x['pre_shared_key_extension'] and not x['early_data_extension'] for x in ch))
        check(cid+'_group',group==case['expected_group_id'])
        check(cid+'_session_outcome',established==case['expected_handshake'])
        check(cid+'_application_arrival',sout==(marker if case['expected_payload_received'] else b''))
        check(cid+'_return_path',cout==(ack if case['expected_payload_received'] else b''))
        check(cid+'_processes_not_forced',not any(x['terminated_by_harness'] for x in (cp,sp,rp)))
        check(cid+'_freeze_before_start',freeze['frozen_at_utc']<cp['started_utc'])
        verdict='NO_SESSION_ESTABLISHED' if not established else ('WITHIN_DECLARED_PROFILE' if group in policy['allowed_group_ids'] else 'OUTSIDE_DECLARED_PROFILE')
        check(cid+'_profile_decision',verdict==case['expected_policy_verdict'])
        if case['expected_handshake']:
            check(cid+'_TLS13_and_cipher',len(sh)==1 and sh[0]['selected_version']==772 and sh[0]['cipher_suite_id']==4866 and not sh[0]['pre_shared_key_selected'])
            check(cid+'_verified_synthetic_peer','Verification: OK' in c_log and 'Verified peername: fazon-lab.invalid' in c_log)
            check(cid+'_plaintext_receiver_and_completed_client',cp['returncode']==0 and sp['returncode']==0 and 'read finished' in s_log)
            label='SecP384r1MLKEM1024' if group==4589 else 'secp384r1'
            check(cid+'_OpenSSL_trace_agrees',label in (d/'client.trace.txt').read_text() and label in (d/'server.trace.txt').read_text())
        else:
            check(cid+'_explicit_rejection',len(sh)==0 and cp['returncode']!=0 and 'no suitable key share' in s_log and {'level':2,'description':40} in decoded['server_to_client']['plaintext_alerts'])
            check(cid+'_no_client_encrypted_records',not any(x['content_type']==23 for x in decoded['client_to_server']['records']))
        rows.append({'case':cid,'session_established':established,'selected_group_id':group,'hello_retry_requests':hrr,'receiver_plaintext_bytes':len(sout),'receiver_plaintext_sha256':sha(sout),'profile_verdict':verdict})
    result={'checked_at_utc':dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z'),'scope':'SEPARATE_OFFLINE_RECHECK_SAME_ENVIRONMENT_SHARED_BOUNDED_PARSER','live_connections_created':0,'checks':checks,'check_count':len(checks),'passed_count':sum(x['passed'] for x in checks),'status':'PASS' if all(x['passed'] for x in checks) else 'FAIL','recomputed_results':rows,'certification_or_independent_lab_validation':False}
    print(json.dumps(result,indent=2));return 0 if result['status']=='PASS' else 2
if __name__=='__main__':raise SystemExit(main())
