#!/usr/bin/env python3
"""Exactly three loopback TLS 1.3 experiments. Writes new evidence only.
No DNS, external target, production config, credentials, GitHub, or upload actions.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, platform, shutil, socket, subprocess, sys, tempfile, threading, time
from pathlib import Path
from wire_decode import decode,selftest

HERE=Path(__file__).resolve().parent

def utc(): return dt.datetime.now(dt.timezone.utc).isoformat().replace('+00:00','Z')
def digest(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write_json(p,data): Path(p).write_text(json.dumps(data,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')

def command(cmd,env,out,prefix):
    start=utc();r=subprocess.run(cmd,env=env,capture_output=True,timeout=15)
    (out/(prefix+'.stdout.txt')).write_bytes(r.stdout);(out/(prefix+'.stderr.txt')).write_bytes(r.stderr)
    write_json(out/(prefix+'.command.json'),{'argv':cmd,'started_utc':start,'ended_utc':utc(),'returncode':r.returncode})
    if r.returncode:raise RuntimeError(prefix+' failed')
    return r.stdout

class Proc:
    def __init__(self,argv,env,out,name):
        self.name=name;self.out=out;self.start=utc();self.argv=argv;self.buf={'stdout':bytearray(),'stderr':bytearray()};self.threads=[];self.terminated=False
        self.p=subprocess.Popen(argv,env=env,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        for chan in ('stdout','stderr'):
            def pump(ch=chan):
                with open(out/(name+'.'+ch+'.txt'),'xb') as f:
                    stream=getattr(self.p,ch)
                    while True:
                        data=os.read(stream.fileno(),65536)
                        if not data:break
                        f.write(data);f.flush();self.buf[ch].extend(data)
            th=threading.Thread(target=pump,daemon=True);th.start();self.threads.append(th)
    def contains(self,ch,b):return b in self.buf[ch]
    def write(self,data):self.p.stdin.write(data);self.p.stdin.flush()
    def finish(self,timeout=5):
        try:rc=self.p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            self.terminated=True;self.p.terminate()
            try:rc=self.p.wait(timeout=2)
            except subprocess.TimeoutExpired:self.p.kill();rc=self.p.wait()
        try:self.p.stdin.close()
        except (OSError,BrokenPipeError):pass
        for th in self.threads:th.join(2)
        result={'argv':self.argv,'pid':self.p.pid,'started_utc':self.start,'ended_utc':utc(),'returncode':rc,'terminated_by_harness':self.terminated,'stdout_bytes':len(self.buf['stdout']),'stderr_bytes':len(self.buf['stderr'])}
        write_json(self.out/(self.name+'.process.json'),result);return result

def free_port():
    with socket.socket(socket.AF_INET,socket.SOCK_STREAM) as s:
        s.bind(('127.0.0.1',0));return s.getsockname()[1]

def wait_listening(port,p,timeout=5):
    # Inspect Linux socket table instead of opening an extra TCP connection.
    deadline=time.monotonic()+timeout;needle='0100007F:'+format(port,'04X')
    while time.monotonic()<deadline:
        if p.poll() is not None:raise RuntimeError('server exited before listen')
        for ln in Path('/proc/net/tcp').read_text().splitlines()[1:]:
            fields=ln.split()
            if fields[1]==needle and fields[3]=='0A':return
        time.sleep(.02)
    raise TimeoutError('SERVER_NOT_LISTENING')

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();root=a.out.resolve()
    if root.exists():raise RuntimeError('OUTPUT_ALREADY_EXISTS; preserve prior run, choose new path')
    root.mkdir(parents=True);(root/'src').mkdir();(root/'environment').mkdir();(root/'raw').mkdir()
    for name in ('run_lab.py','relay.py','wire_decode.py'):shutil.copyfile(HERE/name,root/'src'/name)
    exe=shutil.which('openssl')
    if not exe:raise RuntimeError('OPENSSL_MISSING')
    env={'PATH':os.environ.get('PATH','/usr/bin:/bin'),'LANG':'C','LC_ALL':'C','OPENSSL_CONF':'/dev/null','PYTHONDONTWRITEBYTECODE':'1'}
    protocol={'id':'FAZON_PQC_TLS13_PROFILE_LAB_V0_1','created_at_utc':utc(),'mode':'LOOPBACK_THREE_CASE_EXECUTION_ONLY','allowed_group_ids':[4589],
      'group_registry':{'4589':'SecP384r1MLKEM1024','24':'secp384r1'},'policy_role':'DECLARED_LAB_ACCEPTANCE_BASELINE_NOT_RUNTIME_AUTHORITY_ENGINE',
      'transport':'TLSv1.3 over two loopback TCP legs through byte-preserving recorder','cipher_suite':'TLS_AES_256_GCM_SHA384','cipher_suite_id':4866,
      'certificate_authentication':'Classical ECDSA P-384; ephemeral self-signed local trust anchor','client_identity_authentication':False,
      'session_resumption':False,'early_data':False,'network_targets':['127.0.0.1'],'automated_retry_of_cases':False,'cases':[
       {'id':'C1_APPROVED_HYBRID','client_groups':'SecP384r1MLKEM1024','server_groups':'SecP384r1MLKEM1024','expected_handshake':True,'expected_group_id':4589,'expected_payload_received':True,'expected_policy_verdict':'WITHIN_DECLARED_PROFILE'},
       {'id':'C2_NO_COMMON_APPROVED_GROUP','client_groups':'SecP384r1MLKEM1024','server_groups':'secp384r1','expected_handshake':False,'expected_group_id':None,'expected_payload_received':False,'expected_policy_verdict':'NO_SESSION_ESTABLISHED'},
       {'id':'C3_INJECTED_CLASSICAL_FALLBACK','client_groups':'SecP384r1MLKEM1024:secp384r1','server_groups':'secp384r1','expected_handshake':True,'expected_group_id':24,'expected_payload_received':True,'expected_policy_verdict':'OUTSIDE_DECLARED_PROFILE'}],
      'negative_control':'C3 intentionally widens client configuration; not a network downgrade attack, OpenSSL vulnerability, or enforcement claim.',
      'limits':['No cryptographic security proof','No CNSA or FIPS compliance claim','No FAZON runtime installed or tested','Same-host recorder is a separate observation path, not independent organization','No generic no-effect or route-completeness claim','No performance benchmark','No private-key or TLS-secret publication']}
    write_json(root/'protocol.json',protocol)
    prereg={'frozen_at_utc':utc(),'protocol_sha256':digest(root/'protocol.json'),'source_sha256':{p.name:digest(p) for p in (root/'src').iterdir()},'first_connection_not_started':True,'public_timestamp_or_external_attestation':False}
    write_json(root/'PRE_RUN_FREEZE.json',prereg)
    eo=root/'environment'
    ver=command([exe,'version','-a'],env,eo,'openssl_version').decode()
    groups=command([exe,'list','-tls1_3','-tls-groups'],env,eo,'tls_groups').decode()
    command([exe,'list','-providers','-verbose'],env,eo,'providers')
    for wanted in ('SecP384r1MLKEM1024','secp384r1'):
        if wanted not in groups:raise RuntimeError('MISSING_REQUIRED_GROUP_'+wanted)
    write_json(eo/'environment.json',{'observed_at_utc':utc(),'openssl_executable':exe,'openssl_sha256':digest(exe),'python':sys.version,'os':platform.system(),'release':platform.release(),'machine':platform.machine(),'subprocess_environment':env})
    write_json(eo/'parser_selftest.json',selftest())
    results=[]
    with tempfile.TemporaryDirectory(prefix='fazon-pqc-lab-') as tmp:
        key=str(Path(tmp)/'synthetic_server_key.pem');cert=str(root/'synthetic_server_cert.pem')
        command([exe,'req','-new','-x509','-newkey','ec','-pkeyopt','ec_paramgen_curve:secp384r1','-nodes','-sha384','-keyout',key,'-out',cert,'-days','1','-subj','/CN=fazon-lab.invalid','-addext','subjectAltName=DNS:fazon-lab.invalid','-addext','extendedKeyUsage=serverAuth'],env,eo,'generate_synthetic_certificate')
        for case in protocol['cases']:
            cid=case['id'];out=root/'raw'/cid;out.mkdir();obs=out/'wire';obs.mkdir()
            marker=('FAZON_SYNTHETIC_MARKER_'+cid+'\n').encode();ack=('FAZON_SYNTHETIC_ACK_'+cid+'\n').encode()
            (out/'client_input.bin').write_bytes(marker);(out/'expected_ack.bin').write_bytes(ack)
            port=free_port()
            server_cmd=[exe,'s_server','-accept',f'127.0.0.1:{port}','-4','-cert',cert,'-key',key,'-tls1_3','-groups',case['server_groups'],'-ciphersuites',protocol['cipher_suite'],'-no_ticket','-num_tickets','0','-no_cache','-max_early_data','0','-recv_max_early_data','0','-naccept','1','-quiet','-ign_eof','-state','-trace','-msgfile',str(out/'server.trace.txt')]
            server=Proc(server_cmd,env,out,'server');relay=None;client=None;errors=[];ack_sent=False;deadline_reached=False;start=utc()
            try:
                wait_listening(port,server.p)
                relay=Proc([sys.executable,str(root/'src'/'relay.py'),'--target-port',str(port),'--out',str(obs)],env,out,'relay')
                deadline=time.monotonic()+5
                while not (obs/'relay_ready.json').exists():
                    if relay.p.poll() is not None:raise RuntimeError('relay exited before ready')
                    if time.monotonic()>deadline:raise TimeoutError('relay ready timeout')
                    time.sleep(.02)
                # Atomicity is not claimed; file close is awaited by JSON-read retry without any socket activity.
                for _ in range(20):
                    try:ready=json.loads((obs/'relay_ready.json').read_text());break
                    except json.JSONDecodeError:time.sleep(.01)
                else:raise RuntimeError('relay ready incomplete')
                client_cmd=[exe,'s_client','-connect',f"127.0.0.1:{ready['port']}",'-4','-servername','fazon-lab.invalid','-verify_hostname','fazon-lab.invalid','-verify_return_error','-CAfile',cert,'-no-CApath','-no-CAstore','-tls1_3','-groups',case['client_groups'],'-ciphersuites',protocol['cipher_suite'],'-no_ticket','-brief','-no_ign_eof','-state','-trace','-msgfile',str(out/'client.trace.txt')]
                client=Proc(client_cmd,env,out,'client');client.write(marker)
                deadline=time.monotonic()+12
                while time.monotonic()<deadline:
                    if not ack_sent and server.contains('stdout',marker):
                        server.write(ack);ack_sent=True
                    if ack_sent and client.contains('stdout',ack):break
                    if client.p.poll() is not None:break
                    time.sleep(.02)
                else:deadline_reached=True;errors.append('OBSERVATION_DEADLINE_REACHED')
            except Exception as ex:errors.append(type(ex).__name__+': '+str(ex))
            finally:
                if client:
                    try:client.p.stdin.close()
                    except (OSError,BrokenPipeError):pass
                    cp=client.finish()
                else:cp=None
                sp=server.finish()
                rp=relay.finish() if relay else None
            try:
                cwire=decode((obs/'client_to_server.bin').read_bytes());swire=decode((obs/'server_to_client.bin').read_bytes())
                write_json(obs/'client_to_server.decoded.json',cwire);write_json(obs/'server_to_client.decoded.json',swire)
                sh=[h for h in swire['handshakes'] if h['kind']=='ServerHello'];ch=[h for h in cwire['handshakes'] if h['kind']=='ClientHello']
                group=sh[-1]['selected_group_id'] if sh else None
                established=bool(client and b'CONNECTION ESTABLISHED' in client.buf['stderr'])
                payload=marker in server.buf['stdout'];received_ack=bool(client and ack in client.buf['stdout'])
                verdict='NO_SESSION_ESTABLISHED' if not established else ('WITHIN_DECLARED_PROFILE' if group in protocol['allowed_group_ids'] else 'OUTSIDE_DECLARED_PROFILE')
                relay_result=json.loads((obs/'relay_result.json').read_text())
                checks={'handshake_matches':established==case['expected_handshake'],'selected_group_matches':group==case['expected_group_id'],'payload_matches':payload==case['expected_payload_received'],'policy_verdict_matches':verdict==case['expected_policy_verdict'],'server_application_bytes_exact':bytes(server.buf['stdout'])==(marker if case['expected_payload_received'] else b''),'ack_matches':received_ack==case['expected_payload_received'],'recorder_complete':relay_result['completed'],'one_recorded_session':relay_result['connections_accepted']==1,'no_early_or_psk':bool(ch) and all(not h['early_data_extension'] and not h['pre_shared_key_extension'] for h in ch),'tls13_only':all(h['offered_versions']==[772] for h in ch),'serverhello_tls13_cipher':all(h['selected_version']==772 and h['cipher_suite_id']==4866 for h in sh),'no_forced_process_stop':not any(x and x['terminated_by_harness'] for x in (cp,sp,rp)),'no_harness_error':not errors}
                if not case['expected_handshake']:
                    checks['explicit_fatal_alert']=any(x=={'level':2,'description':40} for x in swire['plaintext_alerts'])
                    checks['explicit_no_suitable_key_share']=b'no suitable key share' in server.buf['stderr']
                    checks['client_nonzero']=bool(cp and cp['returncode']!=0)
                else:checks['client_zero']=bool(cp and cp['returncode']==0)
                result={'case':cid,'started_utc':start,'finished_utc':utc(),'handshake_established':established,'selected_group_id':group,'selected_group_name':sh[-1]['selected_group'] if sh else None,'payload_received':payload,'server_received_bytes':len(server.buf['stdout']),'server_received_sha256':hashlib.sha256(server.buf['stdout']).hexdigest(),'client_received_ack':received_ack,'policy_verdict':verdict,'checks':checks,'test_verdict':'PASS' if all(checks.values()) else 'FAIL','errors':errors,'hello_retry_requests':sum(h['kind']=='HelloRetryRequest' for h in swire['handshakes']),'client_process':cp,'server_process':sp,'relay_process':rp}
            except Exception as ex:result={'case':cid,'test_verdict':'FAIL','errors':errors+[type(ex).__name__+': '+str(ex)]}
            write_json(out/'result.json',result);results.append(result)
            print(json.dumps({k:result.get(k) for k in ('case','test_verdict','selected_group_name','payload_received','policy_verdict','errors')}),flush=True)
        private_key_present_before_cleanup=Path(key).exists()
    write_json(root/'RESULT.json',{'created_at_utc':utc(),'run_status':'PASS_DECLARED_MATRIX' if len(results)==3 and all(r['test_verdict']=='PASS' for r in results) else 'HOLD_REVIEW_REQUIRED','case_count':len(results),'cases':[{'id':r['case'],'test_verdict':r['test_verdict'],'result_path':'raw/'+r['case']+'/result.json'} for r in results],'protocol_sha256_unchanged':digest(root/'protocol.json')==prereg['protocol_sha256'],'private_key_was_created_outside_package':private_key_present_before_cleanup,'private_key_exists_after_temp_cleanup':Path(key).exists(),'private_key_included':False,'github_write':False,'public_response':False,'production_change':False,'fazon_product_runtime_tested':False})
    print('OUTPUT='+str(root),flush=True)
    return 0 if all(r['test_verdict']=='PASS' for r in results) else 2
if __name__=='__main__':raise SystemExit(main())
